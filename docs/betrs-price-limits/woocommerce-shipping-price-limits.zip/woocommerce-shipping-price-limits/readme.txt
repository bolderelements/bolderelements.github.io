=== Plugin Name ===
Contributors: hystericallyme
Donate link: http://bolderelements.net/
Tags: woocommerce, shipping, limit, maximum, max, minimum, min
Requires at least: 4.8
Tested up to: 5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Set a minimum or maximum price to be returned by a single table in the Table Rate Shipping for WooCommerce plugin

== Description ==

Table Rate shipping is a flexible way to create rules for charging shipping. However sometimes the returned amount is too much or not enough. This extension makes it possible to set a minimum or maximum price that the customer will be charged, regardless to what the table returns. If the shipping cost is above the minimum but below the maximum set, then that value will still be the shipping price.

== Installation ==

<h4>Minimum Requirements</h4>

* WooCommerce 2.6 or greater
* WordPress 4.8 or greater
* PHP version 5.6 or greater

<h4>Installation through FTP</h4>

1. Upload the entire `woocommerce-shipping-shipping-price-limits` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. That's it! You will find new options in the 'Additional Settings' box to the right of each shipping table

<h4>Installation through Upload</h4>

1. Navigate to the Plugin Installer in your Dashboard: Plugins > Add New > Upload Plugin (button at top of the page)
2. Upload the `woocommerce-shipping-shipping-price-limits.zip` file and click the 'Install Now' button
3. Activate the plugin through the 'Plugins' menu in WordPress
4. That's it! You will find new options in the 'Additional Settings' box to the right of each shipping table

== Frequently Asked Questions ==

= Where can I find the settings for this plugin? =

This plugin is an extension of the Table Rate Shipping plugin by Bolder Elements. It can be found on the settings page for any of your Table Rate methods in the "Additional Settings" box to the right of every table. The two new fields will be labeled 'Minimum Cost' and 'Maximum Cost'

= Where can I purchase the Table Rate Shipping for WooCommerce plugin? =

You can purchase the parent plugin from the Bolder Elements CodeCanyon portfolio, or at the link below:
https://1.envato.market/bK01g

== Changelog ==

= 1.0 - August 24th, 2019 =
* Initial Release

== Upgrade Notice ==
