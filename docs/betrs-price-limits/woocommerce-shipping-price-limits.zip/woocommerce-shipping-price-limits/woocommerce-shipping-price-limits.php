<?php
/*
 * Plugin Name: Shipping Cost Limitations for BETRS
 * Plugin URI: http://www.bolderelements.net/shipping-cost-limits-woocommerce/
 * Description: Provide minimum or maximum costs to any option for any calculation type (Per Order, Item, or Shipping Class)
 * Author: Bolder Elements
 * Author URI: http://www.bolderelements.net/
 * Version: 1.0
 * WC requires at least: 3.0.0
 * WC tested up to: 3.7.0

	Copyright: © 2019 Bolder Elements (email : info@bolderelements.net)
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

add_action('plugins_loaded', 'woocommerce_shipping_cost_limits_init', 123);

function woocommerce_shipping_cost_limits_init() {

	//Check if WooCommerce is active
	if ( ! class_exists( 'WooCommerce' ) ) return;

	// Check if BETRS is active
	if( ! class_exists( 'BE_Table_Rate_WC' ) ) {
		add_action( 'admin_notices', 'betrs_sl_admin_notice' );
		return;
	}

	// Ensure there are not duplicate classes
	if ( class_exists( 'BE_Shipping_Cost_Limits_WC' ) ) return;

	class BE_Shipping_Cost_Limits_WC {

		/**
		 * Constructor.
		 */
		public function __construct() {

			add_action( 'betrs_additional_rate_settings', array( $this, 'add_settings_fields' ), 23, 2 );
			add_filter( 'betrs_processed_table_rates_settings', array( $this, 'save_settings_fields' ), 23, 1 );
			add_filter( 'betrs_processed_rate', array( $this, 'add_settings_to_processed_ar' ), 23, 3 );
			add_filter( 'betrs_calculated_shipping_options', array( $this, 'apply_min_max_costs' ), 23, 2 );
		}


		/**
		 * Add the Min/Max fields to the settings table.
		 *
		 * @access public
		 * @return void
		 */
		function add_settings_fields( $rowID, $item ) {
			$min_cost = ( isset( $item['min_cost'] ) ) ? wc_format_localized_price( $item['min_cost'] ) : '';
			$max_cost = ( isset( $item['max_cost'] ) ) ? wc_format_localized_price( $item['max_cost'] ) : '';
?>
			<div class="clear">
				<h5><?php _e( 'Minimum Cost', 'be-table-ship' ); ?></h5>
				<div class="regular-input">
<?php
			printf(
				get_woocommerce_price_format(),
	            /*$1%s*/ get_woocommerce_currency_symbol(),
	            /*$2%s*/ '<input type="text" name="min_cost[' . $rowID . ']" id="min_cost[' . $rowID . ']" class="wc_input_price" value="' . $min_cost . '">'
				);
?>
				</div>
			</div>
			<div class="clear">
				<h5><?php _e( 'Maximum Cost', 'be-table-ship' ); ?></h5>
				<div class="regular-input">
<?php
			printf(
				get_woocommerce_price_format(),
	            /*$1%s*/ get_woocommerce_currency_symbol(),
	            /*$2%s*/ '<input type="text" name="max_cost[' . $rowID . ']" id="max_cost[' . $rowID . ']" class="wc_input_price" value="' . $max_cost . '">'
				);
?>
				</div>
			</div>
<?php
		}


		/**
		 * Save the Min/Max fields to the database.
		 *
		 * @access public
		 * @return array
		 */
		function save_settings_fields( $table_rates_saving ) {
			if( ! is_array( $table_rates_saving ) )
				return $table_rates_saving;

			foreach( $table_rates_saving as $key => $rate ) {
				if( isset( $_POST['min_cost'][ $key ] ) ) {
					$table_rates_saving[ $key ]['min_cost'] = wc_format_decimal( sanitize_text_field( $_POST['min_cost'][ $key ] ) );
				}
				if( isset( $_POST['max_cost'][ $key ] ) ) {
					$table_rates_saving[ $key ]['max_cost'] = wc_format_decimal( sanitize_text_field( $_POST['max_cost'][ $key ] ) );
				}
			}

			return $table_rates_saving;
		}


		/**
		 * Adjust an option's cost accordingly.
		 *
		 * @access public
		 * @return void
		 */
		function add_settings_to_processed_ar( $processed_rate, $option, $op_id ) {
			// apply min cost where needed
			if( isset( $option['min_cost'] ) ) {
				$min_cost = wc_format_decimal( $option['min_cost'] );
				$processed_rate['min_cost'] = $min_cost;
			}

			// apply max cost where needed
			if( isset( $option['max_cost'] ) ) {
				$max_cost = wc_format_decimal( $option['max_cost'] );
				$processed_rate['max_cost'] = $max_cost;
			}

			return $processed_rate;
		}


		/**
		 * Adjust an option's cost accordingly.
		 *
		 * @access public
		 * @return void
		 */
		function apply_min_max_costs( $shipping_options, $original_settings ) {

			$first_row = reset( $original_settings );

			foreach( $shipping_options as $key => $value ) {

				// apply min cost where needed
				if( ! empty( $first_row[ $key ]['min_cost'] ) ) {
					$min_cost = (float) wc_format_decimal( $first_row[ $key ]['min_cost'] );
					if( $value['cost'] < $min_cost ) {
						$shipping_options[ $key ]['cost'] = $min_cost;
					}
				}

				// apply max cost where needed
				if( ! empty( $first_row[ $key ]['max_cost'] ) ) {
					$max_cost = (float) wc_format_decimal( $first_row[ $key ]['max_cost'] );
					if( $value['cost'] > $max_cost ) {
						$shipping_options[ $key ]['cost'] = $max_cost;
					}
				}
			}

			return $shipping_options;
		}

	} // end class BE_Shipping_Cost_Limits_WC

	return new BE_Shipping_Cost_Limits_WC();

	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'be_shipping_cost_limits_plugin_action_links' );
	function be_shipping_cost_limits_plugin_action_links( $links ) {
		return array_merge(
			array(
				'settings' => '<a href="' . get_bloginfo( 'wpurl' ) . '/wp-admin/admin.php?page=wc-settings&tab=shipping">' . __( 'Settings', 'betrs-sc' ) . '</a>',
				'support' => '<a href="http://bolderelements.net/" target="_blank">' . __( 'Bolder Elements', 'be-table-ship' ) . '</a>'
			),
			$links
		);
	}
} // end function: woocommerce_shipping_cost_limits_init


/**
 * Generate dashboard notification when not properly installed
 *
 * @access public
 * @return void
 */
function betrs_sl_admin_notice() {
?>
<div class="notice notice-error">
    <p style="font-weight: bold;"><?php _e( 'The Shipping Cost Limitations plugin requires the Table Rate Shipping plugin by Bolder Elements', 'betrs-sc' ); ?></p>
    <p><a href="https://codecanyon.net/item/table-rate-shipping-for-woocommerce/3796656" target="_blank" class="button">
    	<?php _e( 'Purchase Table Rate Shipping', 'betrs-sc' ); ?></a></p>
</div>
<?php
}

/**
 * API check.
 *
 * @since 1.0.0
 *
 * @param bool   $api Always false.
 * @param string $action The API action being performed.
 * @param object $args Plugin arguments.
 * @return mixed $api The plugin info or false.
 */
function betrs_pl_override_plugins_api_result( $res, $action, $args ) {

	if ( isset( $args->slug ) && 'woocommerce-shipping-price-limits' === $args->slug ) {
		$api_check = betrs_pl_override_api_check();
		if ( is_object( $api_check ) ) {
			$res = $api_check;
			$res->external = true;
		}
	}

	return $res;
}
add_filter( 'plugins_api_result', 'betrs_pl_override_plugins_api_result', 5, 3 );


/**
 * Check Github for an update.
 *
 * @since 1.0.0
 *
 * @return false|object
 */
function betrs_pl_override_api_check() {
	$raw_response = wp_remote_get( 'https://bolderelements.github.io/docs/betrs-price-limits/update-check.json' );

	if ( is_wp_error( $raw_response ) ) {
		return false;
	}
	if ( ! empty( $raw_response['body'] ) ) {
		$raw_body = json_decode( trim( $raw_response['body'] ), true );
		if ( $raw_body ) {
			return (object) $raw_body;
		}
	}
	return false;
}
